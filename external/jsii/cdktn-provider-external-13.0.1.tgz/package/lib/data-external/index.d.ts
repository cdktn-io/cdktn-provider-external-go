/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataExternalConfig extends cdktn.TerraformMetaArguments {
    /**
    * A list of strings, whose first element is the program to run and whose subsequent elements are optional command line arguments to the program. Terraform does not execute the program through a shell, so it is not necessary to escape shell metacharacters nor add quotes around arguments containing spaces.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/external/2.3.5/docs/data-sources/external#program DataExternal#program}
    */
    readonly program: string[];
    /**
    * A map of string values to pass to the external program as the query arguments. If not supplied, the program will receive an empty object as its input.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/external/2.3.5/docs/data-sources/external#query DataExternal#query}
    */
    readonly query?: {
        [key: string]: string;
    };
    /**
    * Working directory of the program. If not supplied, the program will run in the current directory.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/external/2.3.5/docs/data-sources/external#working_dir DataExternal#working_dir}
    */
    readonly workingDir?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/external/2.3.5/docs/data-sources/external external}
*/
export declare class DataExternal extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "external";
    /**
    * Generates CDKTN code for importing a DataExternal resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataExternal to import
    * @param importFromId The id of the existing DataExternal that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/external/2.3.5/docs/data-sources/external#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataExternal to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/external/2.3.5/docs/data-sources/external external} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataExternalConfig
    */
    constructor(scope: Construct, id: string, config: DataExternalConfig);
    get id(): string;
    private _program?;
    get program(): string[];
    set program(value: string[]);
    get programInput(): string[] | undefined;
    private _query?;
    get query(): {
        [key: string]: string;
    };
    set query(value: {
        [key: string]: string;
    });
    resetQuery(): void;
    get queryInput(): {
        [key: string]: string;
    } | undefined;
    private _result;
    get result(): cdktn.StringMap;
    private _workingDir?;
    get workingDir(): string;
    set workingDir(value: string);
    resetWorkingDir(): void;
    get workingDirInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
